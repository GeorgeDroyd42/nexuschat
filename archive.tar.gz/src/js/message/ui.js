const MessageUI = {
    createMessageElement(message) {
        const messageEl = document.createElement('div');
        messageEl.className = message.is_webhook ? 'message webhook-message' : 'message';
        messageEl.dataset.messageId = message.message_id;
        messageEl.dataset.userId = message.user_id;
        
        // Create header
        const headerEl = document.createElement('div');
        headerEl.className = 'message-header';
        
        // Create avatar - use same function for all avatars
        let avatarEl = window.createUserAvatarElement(message.username, message.profile_picture);
        
        // Create message info
        const infoEl = document.createElement('div');
        infoEl.className = 'message-info';
        
        const usernameEl = document.createElement('span');
        usernameEl.className = 'message-username';
        
        if (message.is_webhook) {
            usernameEl.innerHTML = `${message.username} <span class="bot-tag">BOT</span>`;
        } else {
            usernameEl.textContent = message.username;
        }
        
        const timeEl = document.createElement('span');
        timeEl.className = 'message-time';
        timeEl.textContent = formatTimestamp(message.created_at, 'time');
        
        infoEl.appendChild(usernameEl);
        infoEl.appendChild(timeEl);
        
        headerEl.appendChild(avatarEl);
        headerEl.appendChild(infoEl);
        
        // Create content (safe from XSS)
        const contentEl = document.createElement('div');
        contentEl.className = 'message-content';
        contentEl.innerHTML = EmbedUtils.linkifyURLs(message.content);
        
        messageEl.appendChild(headerEl);
        messageEl.appendChild(contentEl);

        const embedEl = EmbedUtils.createEmbedElement(message.content);
        if (embedEl) {
            messageEl.appendChild(embedEl);
        }

        return messageEl;
    }
};

window.MessageUI = MessageUI;