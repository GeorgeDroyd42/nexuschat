const MessageAPI = {

    init() {
        this.setupMessageInput();
        this.setupScrollListener();
    },

    setupMessageInput() {
        const messageInput = $('message-input');
        const sendBtn = $('send-message-btn');
        const charCount = $('char-count');


        if (!messageInput) {
            console.error('message-input element not found!');
            return;
        }

        messageInput.addEventListener('input', (e) => {
            const length = e.target.value.length;
            charCount.textContent = `${length}/2000`;
            
            if (length >= 1950) {
                charCount.style.color = 'var(--error-color)';
            } else if (length >= 1800) {
                charCount.style.color = 'var(--warning-color)';
            } else {
                charCount.style.color = 'var(--text-muted)';
            }
            
            sendBtn.disabled = length === 0 || length > 2000;
            
            e.target.style.height = 'auto';
            e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
            
            if (MessageManager.currentChannelId && window.TypingIndicator) {
                window.TypingIndicator.handleInputChange(e.target.value, MessageManager.currentChannelId);
            }
        });

        messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                MessageHandlers.handleSendMessage();
            }
        });

        sendBtn.addEventListener('click', () => MessageHandlers.handleSendMessage());
    },
    renderMessages() {
        const messagesList = $('messages-list');
        if (!messagesList) return;
        
        messagesList.innerHTML = '';
        
        MessageManager.messages.forEach(message => {
            const messageEl = MessageUI.createMessageElement(message);
            messagesList.appendChild(messageEl);
        });
        
        messagesList.scrollTop = messagesList.scrollHeight;
    },



    setupScrollListener() {
        const messagesList = $('messages-list');
        if (!messagesList) return;
        
        messagesList.addEventListener('scroll', () => {
            if (messagesList.scrollTop === 0 && MessageManager.hasMoreMessages && !MessageManager.isLoadingMessages) {
                MessageLoading.loadMoreMessages();
            }
        });
    },
    addNewMessage(message) {
        MessageManager.messages.push(message);
        const messageEl = MessageUI.createMessageElement(message);
        const messagesList = $('messages-list');
        messagesList.appendChild(messageEl);
        messagesList.scrollTop = messagesList.scrollHeight;
    },

async deleteMessage(messageId) {
    if (window.sendMessage) {
        return window.sendMessage({
            type: 'delete_message',
            message_id: messageId
        });
    }
    return false;
}

};

// Debug initialization

document.addEventListener('DOMContentLoaded', () => {
    MessageAPI.init();
});

// Also try immediate initialization in case DOM is already ready
if (document.readyState === 'loading') {
} else {
    MessageAPI.init();
}

window.MessageAPI = MessageAPI;