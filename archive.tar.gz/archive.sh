tar --exclude='**/node_modules' --exclude='**/.git' --exclude='**/data' -czf archive.tar.gz .
