
#!/bin/bash

# Ask for commit message
read -p "Enter commit message: " msg

# Stage all changes
git add .

# Commit with user input
git commit -m "$msg"

# Push to the current branch
branch=$(git branch --show-current)
git push origin "$branch" --force
