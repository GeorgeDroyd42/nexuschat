package embed

const (
	ErrInvalidURL      = 3001
	ErrNetworkFailure  = 3002
	ErrTimeout         = 3003
	ErrInvalidContent  = 3004
	ErrExtractionFailed = 3005
)